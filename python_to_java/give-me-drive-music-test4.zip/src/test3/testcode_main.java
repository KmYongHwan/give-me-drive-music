package test3;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;

public class testcode_main {

	String rain = "calm"; 
	String sunny = "happy"; 
	String cloudy = "depressed"; 
	String thunder = "tense"; 
	String snow = "delighted";

	String hot = "tired"; 
	String cold = "calm"; 
	String mid = "relaxed";

	String spring = "happy";
	String summer = "tired";
	String fall = "calm";
	String winter = "delighted";

	String morning = "tired";
	String launch = "relaxed";
	String afternoon = "tired";
	String night = "happy";
	String dawn = "calm";

	String excited = "exited";
	String delighted = "relaxed";
	String happy = "happy";
	String content = "pleased";
	String relaxed = "calm";
	String calm = "sad";
	String tired = "excited";
	String bored = "excited";
	String depressed = "peaceful";
	String frustrated = "angry";
	String angry = "nervous";
	String tense = "calm";
	
	
	int now = 11;
	String season = "fall";
	Vector<String> weather = new Vector<String>(Arrays.asList("cold", "sunny"));
	String person = "angry";
	String V_a = "bored";
	
	Vector<String> mood = new Vector<String>();
	Vector<String> music = new Vector<String>(12);
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		

	}

}
