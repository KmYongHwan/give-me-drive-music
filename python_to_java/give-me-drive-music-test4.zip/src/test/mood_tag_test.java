package test;

public class mood_tag_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String annoying = 
	}

}
